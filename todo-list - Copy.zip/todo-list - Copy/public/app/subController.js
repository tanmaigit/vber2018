'use strict';

todoApp.controller('SubController', ['$scope', '$state', '$http', '$localStorage',
    function ($scope, $state, $http, $localStorage) {
		$http.get('/api/v1/car').then(
			function(reponse){
				console.log(reponse);
			}, 
			function(failedReponse){
				console.log(failedReponse);
			}
		);
		$scope.hello = "Create";
    }
]
);