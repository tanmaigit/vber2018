'use strict';

var todoApp = angular.module('todoApp', ['ui.router', 'ngStorage']);

todoApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/my-todo');

    $stateProvider
        .state('my-todo', {
            url: '/my-todo',
			controller: 'HomeController',
            templateUrl: '/app/index.html'
        })
		.state('login', {
            url: '/login',
			controller: 'CreateController',
            templateUrl: '/app/create.html'
        })
		.state('sub1', {
            url: '/sub1',
			controller: 'SubController',
            templateUrl: '/app/sub.html'
        });
});

todoApp.run(function($rootScope, $location, $localStorage, $http) {
	// if user is logged in
	if ($localStorage.loggedUser) {
		$http.defaults.headers.common.Authorization = 'Bearer ' + $localStorage.loggedUser.token;
	}
	
	// redirect to login page if user is not logged in
	$rootScope.$on('$locationChangeStart', function (event, next, current) {
		if (!$localStorage.loggedUser && $location.path() !== '/login') {
			$location.path('/login');
		}
	});
});