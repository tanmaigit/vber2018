'use strict';

todoApp.controller('CreateController', ['$scope', '$state', '$http', '$localStorage',
    function ($scope, $state, $http, $localStorage) {
		$http.post('/api/v1/login', { email: 'tanmai@gmail.com' }).then(
			function(reponse){
				console.log(reponse);
				$localStorage.loggedUser = reponse.data;
				$state.go('my-todo');
			}, 
			function(failedReponse){
				console.log(failedReponse);
			}
		);
		$scope.hello = "Create";
    }
]
);