<?php
 
namespace App\Http\Controllers;
 
use App\Car;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
 
class CarController extends Controller{

	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
	
	public function login(Request $request){
    	if($request->input('email')){
			return response()->json(['token' => 'token_123456789_' . $request->input('email')]);
		}else{
			return response()->json(['status' => 'fail'], 401);
		}
	}

	public function createCar(Request $request){
 
    	$car = Car::create($request->all());
 
    	return response()->json($car);
 
	}
 
	public function updateCar(Request $request, $id){

    	$car  = Car::find($id);
    	$car->make = $request->input('make');
    	$car->model = $request->input('model');
    	$car->year = $request->input('year');
    	$car->save();
 
    	return response()->json($car);
	}  

	public function deleteCar($id){
    	$car  = Car::find($id);
    	$car->delete();
 
    	return response()->json('Removed successfully.');
	}

	public function index(Request $request){
    	//$cars  = Car::all();
    	return response()->json([$request->header('Authorization')]);
 
	}
}
?>