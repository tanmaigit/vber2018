<?php namespace App;
 
use Illuminate\Database\Eloquent\Model;
 
class ToDo extends Model
{
 	protected $fillable = ['id', 'name', 'description', 'status', 'user_id'];
	public $timestamps = false;
}
?>