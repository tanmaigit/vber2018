<html>
  <head>
    <meta charset="utf-8">
    <title>ToDo List</title>
    <link rel="stylesheet" href="/bower_components/bootstrap/dist/css/bootstrap.css" />
  </head>
  <body ng-app="todoApp">
	<div ui-view></div>
	<script src="/bower_components/jquery/jquery.js"></script>
    <script src="/bower_components/angular/angular.js"></script>
	<script src="/bower_components/ui-router/release/angular-ui-router.js"></script>
	<script src="/bower_components/ngstorage/ngStorage.min.js"></script>
	<script src="/bower_components/bootstrap/dist/js/bootstrap.js"></script>
	<script src="/app/app.js"></script>
	<script src="/app/homeController.js"></script>
	<script src="/app/createController.js"></script>
	<script src="/app/subController.js"></script>
  </body>
</html>