'use strict';

lumenApp.controller('HomeController', ['$scope', '$state',
    function ($scope, $state) {

		$scope.hello = "Tan";
		
		$scope.clicker = function () {
			console.log($state);
			$state.go('create');
		};
    }
]
);