'use strict';

var lumenApp = angular.module('lumenApp', ['ui.router']);