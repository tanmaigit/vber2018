'use strict';

lumenApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/home');

    $stateProvider
        .state('home', {
            url: '/home',
			controller: 'HomeController',
            templateUrl: '/app/index.html'
        })
		.state('create', {
            url: '/create',
			controller: 'CreateController',
            templateUrl: '/app/create.html'
        });
});
