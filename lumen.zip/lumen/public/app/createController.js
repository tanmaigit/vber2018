'use strict';

lumenApp.controller('CreateController', ['$scope', '$state',
    function ($scope, $state) {

		$scope.hello = "Create";
    }
]
);