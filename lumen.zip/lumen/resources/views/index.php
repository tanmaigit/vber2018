<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8">
    <title>Lumen3</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <!-- build:css(app) styles/vendor.css -->
    <!-- bower:css -->
    <link rel="stylesheet" href="/bower_components/bootstrap/dist/css/bootstrap.css" />
    <!-- endbower -->
    <!-- endbuild -->

    <!-- build:css({.tmp,src/app}) styles/main.css -->
    <!-- endbuild -->
  </head>
  <body ng-app="lumenApp">
	<div ui-view></div>
	<script src="/bower_components/jquery/jquery.js"></script>
    <script src="/bower_components/jquery-ui/jquery-ui.js"></script>
    <script src="/bower_components/angular/angular.js"></script>
	<script src="/bower_components/ui-router/release/angular-ui-router.js"></script>
	<script src="/bower_components/bootstrap/dist/js/bootstrap.js"></script>
	<script src="/app/app.js"></script>
	<script src="/app/states.js"></script>
	<script src="/app/homeController.js"></script>
	<script src="/app/createController.js"></script>
  </body>
</html>